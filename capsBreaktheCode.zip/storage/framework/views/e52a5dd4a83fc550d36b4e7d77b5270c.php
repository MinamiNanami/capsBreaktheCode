

<?php $__env->startSection('content'); ?>
<section id="load-approval-section" class="content-section">
    <h2 class="text-2xl font-bold mb-4">Requests Approval</h2>

    
    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-800 p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="bg-red-100 text-red-800 p-3 rounded mb-4">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    
    <table class="w-full border-collapse border border-gray-300">
        <thead class="bg-gray-100">
            <tr>
                <th class="border px-2 py-1">Request ID</th>
                <th class="border px-2 py-1">Type</th>
                <th class="border px-2 py-1">User</th>
                <th class="border px-2 py-1">Email</th>
                <th class="border px-2 py-1">Amount</th>
                <th class="border px-2 py-1">Status</th>
                <th class="border px-2 py-1">Date</th>
                <th class="border px-2 py-1">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-100">
                <td class="border px-2 py-1"><?php echo e($req->id); ?></td>
                <td class="border px-2 py-1"><?php echo e($req->type); ?></td>
                <td class="border px-2 py-1"><?php echo e($req->user->name); ?></td>
                <td class="border px-2 py-1"><?php echo e($req->user->email); ?></td>
                <td class="border px-2 py-1">₱ <?php echo e(number_format($req->amount, 2)); ?></td>
                <td class="border px-2 py-1">
                    <?php if($req->status === 'pending'): ?>
                        <span class="text-yellow-600 font-semibold">Pending</span>
                    <?php elseif($req->status === 'approved'): ?>
                        <span class="text-green-600 font-semibold">Approved</span>
                    <?php else: ?>
                        <span class="text-red-600 font-semibold">Rejected</span>
                    <?php endif; ?>
                </td>
                <td class="border px-2 py-1"><?php echo e($req->created_at->format('Y-m-d H:i')); ?></td>
                <td class="border px-2 py-1 flex gap-2">
                    <?php if($req->status === 'pending'): ?>
                        
                        <form action="<?php echo e(route('requests.approve', $req->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="type" value="<?php echo e($req->type); ?>">
                            <button type="submit" class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700">
                                Approve
                            </button>
                        </form>

                        
                        <form action="<?php echo e(route('requests.reject', $req->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <input type="hidden" name="type" value="<?php echo e($req->type); ?>">
                            <button type="submit" class="bg-red-600 text-white px-3 py-1 rounded hover:bg-red-700">
                                Reject
                            </button>
                        </form>
                    <?php else: ?>
                        <span class="text-gray-500 italic">No actions</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8" class="text-center py-3 text-gray-500">No requests found</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\capsBreaktheCode\resources\views/load_approval.blade.php ENDPATH**/ ?>