<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff POS - Jariel's Peak</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #f0fdf4 0%, #ecfdf5 30%, #d1fae5 70%, #bbf7d0 100%);
            min-height: 100vh;
        }

        /* Header Styles */
        .header {
            background: rgba(255, 255, 255, 0.8);
            backdrop-filter: blur(20px);
            border-bottom: 1px solid rgba(34, 197, 94, 0.1);
            padding: 1rem 2rem;
            text-align: center;
        }

        .header h1 {
            color: #15803d;
            font-size: 2.5rem;
            font-weight: bold;
            text-shadow: 0 2px 4px rgba(255, 255, 255, 0.5);
        }

        /* Category Buttons */
        .category-container {
            display: flex;
            justify-content: center;
            gap: 1rem;
            margin: 2rem 0;
            flex-wrap: wrap;
            max-width: 1200px;
            margin-left: auto;
            margin-right: auto;
            padding: 0 2rem;
        }

        .category-btn {
            padding: 12px 24px;
            background: rgba(255, 255, 255, 0.9);
            border: 1px solid rgba(34, 197, 94, 0.1);
            border-radius: 30px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 600;
            font-size: 14px;
            color: #16a34a;
            box-shadow: 0 4px 15px rgba(34, 197, 94, 0.1);
        }

        .category-btn.active {
            background: linear-gradient(135deg, #86efac, #4ade80);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(34, 197, 94, 0.25);
        }

        .category-btn:hover:not(.active) {
            background: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(34, 197, 94, 0.2);
            color: #15803d;
            border-color: rgba(34, 197, 94, 0.2);
        }

        /* Alert Styles */
        .alert-success {
            background: rgba(74, 222, 128, 0.1);
            border: 1px solid rgba(74, 222, 128, 0.3);
            color: #15803d;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 1rem;
            font-weight: 600;
        }

        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #dc2626;
            padding: 12px 16px;
            border-radius: 12px;
            margin-bottom: 1rem;
            font-weight: 600;
        }

        /* Products Container */
        .products-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 2rem;
        }

        /* Product Cards */
        .product-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 8px 25px rgba(34, 197, 94, 0.08);
            transition: all 0.3s ease;
            position: relative;
            border: 1px solid rgba(34, 197, 94, 0.08);
        }

        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(34, 197, 94, 0.15);
            border-color: rgba(34, 197, 94, 0.15);
        }

        .product-image {
            width: 100%;
            height: 200px;
            object-fit: cover;
        }

        .product-image-placeholder {
            width: 100%;
            height: 200px;
            background: linear-gradient(135deg, #f0fdf4, #dcfce7);
            display: flex;
            align-items: center;
            justify-content: center;
            color: #22c55e;
            font-size: 14px;
        }

        .product-info {
            padding: 1.5rem;
        }

        .product-name {
            font-size: 1.25rem;
            font-weight: bold;
            color: #15803d;
            margin-bottom: 0.5rem;
        }

        .product-description {
            color: #6b7280;
            font-size: 14px;
            margin-bottom: 1rem;
            line-height: 1.4;
        }

        .product-price {
            font-size: 1.5rem;
            font-weight: bold;
            color: #22c55e;
            margin-bottom: 0.5rem;
        }

        .product-category {
            font-size: 12px;
            color: #9ca3af;
            margin-bottom: 1rem;
        }

        .add-to-cart-btn {
            background: linear-gradient(135deg, #86efac, #4ade80);
            color: white;
            border: none;
            padding: 12px;
            border-radius: 50px;
            font-weight: bold;
            cursor: pointer;
            width: 100%;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .add-to-cart-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(134, 239, 172, 0.4);
            background: linear-gradient(135deg, #4ade80, #22c55e);
        }

        .add-to-cart-btn:active {
            transform: translateY(0);
        }

        /* Cart Panel */
        #cart-panel {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(20px);
            border-radius: 20px;
            box-shadow: 0 15px 35px rgba(34, 197, 94, 0.1);
            border: 1px solid rgba(34, 197, 94, 0.1);
        }

        #cart-table {
            font-size: 14px;
        }

        #cart-table th {
            background: rgba(220, 252, 231, 0.5);
            color: #15803d;
            font-weight: 600;
            padding: 12px 8px;
        }

        #cart-table td {
            padding: 12px 8px;
            border-bottom: 1px solid rgba(34, 197, 94, 0.08);
        }

        #cart-table input[type="number"] {
            width: 3rem;
            padding: 0.25rem;
            border: 2px solid #dcfce7;
            border-radius: 8px;
            text-align: center;
            transition: all 0.3s ease;
        }

        #cart-table input[type="number"]:focus {
            border-color: #4ade80;
            outline: none;
        }

        .remove-btn {
            color: #dc2626;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            background: none;
            border: none;
            padding: 4px 8px;
            border-radius: 6px;
        }

        .remove-btn:hover {
            color: #991b1b;
            transform: scale(1.1);
            background: rgba(239, 68, 68, 0.1);
        }

        .form-input,
        .form-select {
            width: 100%;
            border: 2px solid #dcfce7;
            border-radius: 12px;
            padding: 12px;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.9);
        }

        .form-input:focus,
        .form-select:focus {
            border-color: #4ade80;
            outline: none;
            background: white;
        }

        #checkout-btn {
            background: linear-gradient(135deg, #4ade80, #22c55e);
            color: white;
            border: none;
            padding: 15px;
            border-radius: 50px;
            font-weight: bold;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            transition: all 0.3s ease;
            margin-top: 1rem;
        }

        #checkout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(74, 222, 128, 0.4);
            background: linear-gradient(135deg, #22c55e, #16a34a);
        }

        #checkout-btn:disabled {
            opacity: 0.6;
            cursor: not-allowed;
            transform: none;
        }

        /* Empty state */
        .empty-state {
            text-align: center;
            color: #15803d;
            font-size: 1.125rem;
            font-weight: 600;
            padding: 4rem 2rem;
        }

        /* Mobile Responsive */
        @media (max-width: 768px) {
            .header {
                padding: 1rem;
            }

            .header h1 {
                font-size: 1.5rem;
            }

            .products-container {
                padding: 0 1rem;
            }

            .category-container {
                margin: 1rem 0;
                gap: 0.5rem;
                padding: 0 1rem;
            }

            .category-btn {
                padding: 8px 16px;
                font-size: 12px;
            }
        }

        /* Make cart sticky on desktop */
        @media (min-width: 768px) {
            #cart-panel {
                position: sticky;
                top: 6rem;
                max-height: calc(100vh - 6rem);
                overflow-y: auto;
            }
        }
    </style>
</head>

<body>
    <!-- Header -->
    <div class="header flex items-center justify-center gap-4">
        <img src="<?php echo e(asset('images/logo.png')); ?>" alt="Jariel's Peak Logo" class="h-20 w-auto">
        <h1>STAFF POS - JARIEL'S PEAK</h1>
    </div>

    <div class="container mx-auto p-6">
        <?php if(session('success')): ?>
        <div class="alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
        <div class="alert-error"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <!-- Category Buttons -->
        <div class="category-container">
            <button class="category-btn active" data-category="all">All</button>
            <button class="category-btn" data-category="Main Dish">Main Dish</button>
            <button class="category-btn" data-category="Exotic Dish / Silog">Exotic Dish / Silog</button>
            <button class="category-btn" data-category="Pancit">Pancit</button>
            <button class="category-btn" data-category="Rice">Rice</button>
            <button class="category-btn" data-category="Vegetables">Vegetables</button>
            <button class="category-btn" data-category="Beverages">Beverages</button>
        </div>

        <div class="md:flex md:gap-6">
            <!-- Products Grid -->
            <div class="md:flex-1 products-container">
                <?php if($products->isEmpty()): ?>
                <div class="empty-state">
                    🍽️ No products available right now.
                </div>
                <?php else: ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-2 lg:grid-cols-3 gap-6" id="products-grid">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="product-card" data-category="<?php echo e($product->category); ?>">
                        <?php if($product->image): ?>
                        <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>"
                            class="product-image">
                        <?php else: ?>
                        <div class="product-image-placeholder">
                            No Image Available
                        </div>
                        <?php endif; ?>
                        <div class="product-info">
                            <h2 class="product-name"><?php echo e($product->name); ?></h2>
                            <p class="product-description"><?php echo e($product->description ?? 'Delicious food item'); ?></p>
                            <p class="product-price">₱ <?php echo e(number_format($product->price, 2)); ?></p>
                            <p class="product-category">Category: <?php echo e(ucfirst($product->category)); ?></p>
                            <button class="add-to-cart-btn" data-id="<?php echo e($product->id); ?>"
                                data-name="<?php echo e($product->name); ?>" data-price="<?php echo e($product->price); ?>">
                                ➕ Add to Cart
                            </button>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Cart Panel -->
            <div id="cart-panel" class="md:w-80 p-6 mt-6 md:mt-0">
                <h2 class="text-2xl font-bold mb-4 text-gray-800">🛒 Cart</h2>
                <form action="<?php echo e(route('staff.sales.store')); ?>" method="POST" id="cart-form">
                    <?php echo csrf_field(); ?>
                    <div class="overflow-x-auto">
                        <table class="w-full mb-4" id="cart-table">
                            <thead>
                                <tr>
                                    <th class="text-left">Item</th>
                                    <th class="text-left">Price</th>
                                    <th class="text-left">Qty</th>
                                    <th class="text-left">Subtotal</th>
                                    <th class="text-left">Remove</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="text-right font-bold text-xl text-gray-800 mb-4">
                        Total: ₱<span id="cart-total">0.00</span>
                    </div>

                    <!-- Hidden input for items -->
                    <input type="hidden" name="items" id="cart-items-input">

                    <!-- Order Method -->
                    <div class="mb-4">
                        <label class="block text-gray-700 font-semibold mb-2">Order Method</label>
                        <select id="order-method" name="order_method" class="form-select">
                            <option value="Takeout">🥡 Takeout</option>
                            <option value="Dine-in">🍽️ Dine-in</option>
                        </select>
                    </div>

                    <!-- Table Number -->
                    <div class="mb-4" id="table-number-div" style="display:none;">
                        <label class="block text-gray-700 font-semibold mb-2">Table Number</label>
                        <input type="text" id="table-number" name="table_number" class="form-input"
                            placeholder="Enter table number">
                    </div>

                    <!-- Payment Method -->
                    <div class="mb-4">
                        <label class="block text-gray-700 font-semibold mb-2">Payment Method</label>
                        <select id="payment-method" name="payment_method" class="form-select">
                            <option value="Cash">💵 Cash</option>
                            <option value="GCash">📱 GCash</option>
                        </select>
                    </div>

                    <button type="submit" id="checkout-btn">
                        🎯 Checkout
                    </button>
                </form>
            </div>
        </div>
    </div>

    <script>
        // ---------- Category Filter ----------
        const categoryButtons = document.querySelectorAll('.category-btn');
        const products = document.querySelectorAll('#products-grid .product-card');

        categoryButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                categoryButtons.forEach(b => b.classList.remove('active'));
                btn.classList.add('active');

                const selectedCategory = btn.dataset.category;
                products.forEach(product => {
                    product.style.display = selectedCategory === 'all' || product.dataset.category === selectedCategory ? 'block' : 'none';
                });
            });
        });

        // ---------- Cart Functionality ----------
        const cart = [];

        function renderCart() {
            const tbody = document.querySelector('#cart-table tbody');
            tbody.innerHTML = '';
            let total = 0;

            cart.forEach((item, index) => {
                const subtotal = item.price * item.quantity;
                total += subtotal;

                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td class="font-medium">${item.name}</td>
                    <td>₱ ${item.price.toFixed(2)}</td>
                    <td><input type="number" value="${item.quantity}" min="1" class="quantity-input" data-index="${index}"></td>
                    <td class="font-semibold">₱ ${subtotal.toFixed(2)}</td>
                    <td><button type="button" class="remove-btn" data-index="${index}">🗑️ Remove</button></td>
                `;
                tbody.appendChild(tr);
            });

            document.getElementById('cart-total').textContent = total.toFixed(2);
            document.getElementById('cart-items-input').value = JSON.stringify(cart);

            document.querySelectorAll('.quantity-input').forEach(input => {
                input.addEventListener('change', e => {
                    const idx = e.target.dataset.index;
                    cart[idx].quantity = parseInt(e.target.value) || 1;
                    renderCart();
                });
            });

            document.querySelectorAll('.remove-btn').forEach(btn => {
                btn.addEventListener('click', e => {
                    const idx = e.target.dataset.index;
                    cart.splice(idx, 1);
                    renderCart();
                });
            });
        }

        document.querySelectorAll('.add-to-cart-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = btn.dataset.id;
                const name = btn.dataset.name;
                const price = parseFloat(btn.dataset.price);

                const existing = cart.find(item => item.id == id);
                if (existing) existing.quantity += 1;
                else cart.push({ id, name, price, quantity: 1 });

                renderCart();

                btn.style.background = 'linear-gradient(135deg, #4ade80, #22c55e)';
                btn.innerHTML = '✅ Added!';
                setTimeout(() => {
                    btn.style.background = 'linear-gradient(135deg, #86efac, #4ade80)';
                    btn.innerHTML = '➕ Add to Cart';
                }, 1000);
            });
        });

        const orderMethodSelect = document.getElementById('order-method');
        const tableNumberDiv = document.getElementById('table-number-div');
        orderMethodSelect.addEventListener('change', () => {
            tableNumberDiv.style.display = orderMethodSelect.value === 'Dine-in' ? 'block' : 'none';
        });

        // ---------- Printable Receipt ----------
        function printReceipt(orderData) {
            const receiptWindow = window.open('', 'PRINT', 'height=600,width=400');
            receiptWindow.document.write(`
                <html>
                <head>
                    <title>Receipt - Jariel's Peak</title>
                    <style>
                        body { font-family: 'Courier New', monospace; padding: 1rem; }
                        .header { text-align: center; font-weight: bold; color: #15803d; margin-bottom: 1rem; }
                        .items { width: 100%; border-collapse: collapse; margin-bottom: 1rem; }
                        .items th, .items td { padding: 4px 0; border-bottom: 1px dashed #22c55e; }
                        .total { text-align: right; font-weight: bold; margin-top: 1rem; }
                        .footer { text-align: center; margin-top: 1.5rem; font-size: 0.8rem; color: #4b5563; }
                    </style>
                </head>
                <body>
                    <div class="header">
                        JARIEL'S PEAK<br>
                        Staff POS Receipt<br>
                        ${new Date().toLocaleString()}
                    </div>
                    <div>
                        <strong>Order Method:</strong> ${orderData.order_method}<br>
                        ${orderData.order_method === 'Dine-in' ? `<strong>Table Number:</strong> ${orderData.table_number}<br>` : ''}
                        <strong>Payment Method:</strong> ${orderData.payment_method}
                    </div>
                    <table class="items">
                        <thead><tr><th>Item</th><th>Qty</th><th>Subtotal</th></tr></thead>
                        <tbody>
                            ${orderData.items.map(item => `
                                <tr>
                                    <td>${item.name}</td>
                                    <td>${item.quantity}</td>
                                    <td>₱ ${(item.price * item.quantity).toFixed(2)}</td>
                                </tr>
                            `).join('')}
                        </tbody>
                    </table>
                    <div class="total">
                        Total: ₱ ${orderData.items.reduce((sum, i) => sum + i.price * i.quantity, 0).toFixed(2)}
                    </div>
                    <div class="footer">
                        Thank you for your order!<br>
                        Visit us again at Jariel's Peak.
                    </div>
                </body>
                </html>
            `);
            receiptWindow.document.close();
            receiptWindow.focus();
            receiptWindow.print();
            receiptWindow.close();
        }

        document.getElementById('cart-form').addEventListener('submit', e => {
            if (cart.length === 0) {
                e.preventDefault();
                alert('🛒 Cart is empty! Please add some items first.');
                return;
            }

            if (orderMethodSelect.value === 'Dine-in' && document.getElementById('table-number').value.trim() === '') {
                e.preventDefault();
                alert('📍 Please enter a table number for dine-in orders.');
                return;
            }

            // Prepare order data
            const orderData = {
                items: cart,
                order_method: orderMethodSelect.value,
                table_number: document.getElementById('table-number').value,
                payment_method: document.getElementById('payment-method').value
            };

            // Print receipt
            printReceipt(orderData);

            // Submit form after printing
            e.target.submit();
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\capsBreaktheCode\resources\views/staff.blade.php ENDPATH**/ ?>