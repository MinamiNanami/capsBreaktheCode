

<?php $__env->startSection('content'); ?>
<section id="blockchain-section" class="content-section">
    <h2 class="text-2xl font-bold mb-4">Blockchain & Tokens</h2>

    <!-- Users Token Balances -->
    <h3 class="text-xl font-bold mb-2">User Token Balances</h3>
    <table class="w-full border-collapse border border-gray-300 mb-6">
        <thead class="bg-gray-100">
            <tr>
                <th class="border px-2 py-1">User</th>
                <th class="border px-2 py-1">Email</th>
                <th class="border px-2 py-1">Tokens (Wallet Balance)</th>
                <th class="border px-2 py-1">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover:bg-gray-100">
                <td class="border px-2 py-1"><?php echo e($user->name); ?></td>
                <td class="border px-2 py-1"><?php echo e($user->email); ?></td>
                <td class="border px-2 py-1"><?php echo e(number_format($user->wallet_balance,2)); ?></td>
                <td class="border px-2 py-1">
                    <button class="mint-token-btn px-2 py-1 bg-blue-600 text-white rounded hover:bg-blue-700"
                        data-id="<?php echo e($user->id); ?>"
                        data-name="<?php echo e($user->name); ?>">Mint Tokens</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <!-- Mint Token Modal -->
    <div id="mint-modal" class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 hidden z-50">
        <div class="bg-white p-6 rounded-lg w-96 relative">
            <span id="close-mint-modal" class="absolute top-2 right-3 cursor-pointer text-xl">&times;</span>
            <h3 class="text-xl font-bold mb-4">Mint Tokens</h3>
            <form action="<?php echo e(route('blockchain.mint')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="user_id" id="mint-user-id">

                <label>User:</label>
                <input type="text" id="mint-user-name" class="border p-2 rounded w-full mb-2" readonly>

                <label>Amount:</label>
                <input type="number" name="amount" id="mint-amount" class="border p-2 rounded w-full mb-2" min="1" required>

                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 w-full">Mint</button>
            </form>
        </div>
    </div>

    <!-- Token Transaction History -->
    <h3 class="text-xl font-bold mb-2 mt-6">Recent Transactions</h3>
    <table class="w-full border-collapse border border-gray-300">
        <thead class="bg-gray-100">
            <tr>
                <th class="border px-2 py-1">User</th>
                <th class="border px-2 py-1">Amount</th>
                <th class="border px-2 py-1">Type</th>
                <th class="border px-2 py-1">Date</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover:bg-gray-100">
                <td class="border px-2 py-1"><?php echo e($tx->user->name); ?></td>
                <td class="border px-2 py-1"><?php echo e(number_format($tx->amount,2)); ?></td>
                <td class="border px-2 py-1"><?php echo e(ucfirst($tx->type)); ?></td>
                <td class="border px-2 py-1"><?php echo e($tx->created_at->format('Y-m-d H:i')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <script>
        const mintModal = document.getElementById('mint-modal');
        const closeMintModal = document.getElementById('close-mint-modal');
        const mintUserIdInput = document.getElementById('mint-user-id');
        const mintUserNameInput = document.getElementById('mint-user-name');
        const mintAmountInput = document.getElementById('mint-amount');

        document.querySelectorAll('.mint-token-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                mintUserIdInput.value = btn.dataset.id;
                mintUserNameInput.value = btn.dataset.name;
                mintAmountInput.value = '';
                mintModal.classList.remove('hidden');
            });
        });

        closeMintModal.addEventListener('click', () => mintModal.classList.add('hidden'));
        mintModal.addEventListener('click', e => {
            if (e.target === mintModal) mintModal.classList.add('hidden');
        });
    </script>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\capsBreaktheCode\resources\views/blockchain.blade.php ENDPATH**/ ?>