<?php

namespace App\Http\Controllers;

use App\Models\BalanceRequest;
use App\Models\LoadRequest;
use App\Models\adminController;
use App\Models\dashboardController;
use App\Models\InventoryController;
use App\Models\kioskController;
use App\Models\loadApprovalController;
use App\Models\loadRequestController;
use App\Models\POSController;
use App\Models\productController;
use App\Models\ProfileController;
use App\Models\saleController;
use App\Models\staffController;
use App\Models\transactionController;
use App\Models\userController;
use App\Models\userWalletController;
use App\Models\walletController;


abstract class Controller
{
    public function index()
    {
        $loadRequests = LoadRequest::with('user')->get();
        $balanceRequests = BalanceRequest::with('user')->get();

        // Tag each request so you know where it came from
        $loadRequests->each(function ($item) {
            $item->type = 'Load';
        });

        $balanceRequests->each(function ($item) {
            $item->type = 'Balance';
        });

        // Merge both collections
        $requests = $loadRequests->merge($balanceRequests)->sortByDesc('created_at');

        return view('load-approval', compact('requests'));
    }
}
