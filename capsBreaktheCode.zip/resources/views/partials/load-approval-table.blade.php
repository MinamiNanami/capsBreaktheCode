<div class="table-container">
    <table id="loadApprovalTable">
        <thead>
            <tr>
                <th>User</th>
                <th>Amount</th>
                <th>Status</th>
                <th>Requested At</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Dynamic load approval rows -->
        </tbody>
    </table>
</div>
