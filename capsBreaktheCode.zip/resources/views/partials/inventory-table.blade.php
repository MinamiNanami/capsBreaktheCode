<div class="table-container">
    <table id="inventoryTable">
        <thead>
            <tr>
                <th>Product</th>
                <th>Stock</th>
                <th>Category</th>
                <th>Last Updated</th>
            </tr>
        </thead>
        <tbody>
            <!-- Inventory rows dynamically generated here -->
        </tbody>
    </table>
</div>
