<div class="table-container">
    <table id="transactionsTable">
        <thead>
            <tr>
                <th>Transaction ID</th>
                <th>User</th>
                <th>Total</th>
                <th>Date</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <!-- Dynamic transactions rows will go here -->
        </tbody>
    </table>
</div>
