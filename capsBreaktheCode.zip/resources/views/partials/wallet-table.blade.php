<div class="table-container">
    <table id="walletTable">
        <thead>
            <tr>
                <th>User</th>
                <th>Balance</th>
                <th>Last Transaction</th>
            </tr>
        </thead>
        <tbody>
            <!-- Dynamic wallet rows -->
        </tbody>
    </table>
</div>
